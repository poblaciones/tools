﻿//////////////////////////////////////////////////////////////////////////////
// This source code and all associated files and resources are copyrighted by
// the author(s). This source code and all associated files and resources may
// be used as long as they are used according to the terms and conditions set
// forth in The Code Project Open License (CPOL), which may be viewed at
// http://www.blackbeltcoder.com/Legal/Licenses/CPOL.
//
// This code was original published on Black Belt Coder
// (http://www.blackbeltcoder.com).
//
// Copyright (c) 2011 Jonathan Wood
//

using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.Design;

namespace BlackBeltCoder
{
	/// <summary>
	/// Simple tool strip button that stores and displays a color value.
	/// </summary>
	[ToolStripItemDesignerAvailability(ToolStripItemDesignerAvailability.ToolStrip|
		ToolStripItemDesignerAvailability.StatusStrip)]
	public class ColorToolStripButton : ToolStripButton
	{
		// Events
		public delegate void ColorPaletteEventHandler(object sender, ColorPickerEventArgs e);
		public new event ColorPaletteEventHandler Click;

		// Properties
		protected Color _value;

		[Description("Gets or sets the current color value for this control instance.")]
		[DefaultValue(KnownColor.White)]
		public Color Value
		{
			get { return _value; }
			set { _value = value; Invalidate(); }
		}

		// Constructor
		public ColorToolStripButton()
		{
			Value = Color.White;
			base.Click += new System.EventHandler(ColorToolStripButton_Click);
		}

		// Handle button click
		void ColorToolStripButton_Click(object sender, System.EventArgs e)
		{
			if (Click != null)
			{
				ColorPickerEventArgs args = new ColorPickerEventArgs();
				args.Value = Value;
				Click(this, args);
			}
		}

		// Render control
		protected override void OnPaint(PaintEventArgs e)
		{
			// Render background
			ToolStripItemRenderEventArgs args = new ToolStripItemRenderEventArgs(e.Graphics, this);
			Parent.Renderer.DrawButtonBackground(args);

			// Render color box
			Rectangle rect = new Rectangle(3, 3, 15, 15);
			e.Graphics.FillRectangle(new SolidBrush(Value), rect);
			e.Graphics.DrawRectangle(Pens.Black, rect);
		}
	}
}
